import React, { useEffect, useState } from "react";
import { StyleSheet, View } from "react-native";
import Main from "./pages/Main";
import SplashScreen from "./pages/SplashScreen";
import { NavigationContainer } from "@react-navigation/native";
import HomePage from "./pages/HomePage";
import LevelPage from "./pages/LevelPage";
import ResultsPage from "./pages/ResultPage";
import { createStackNavigator } from "@react-navigation/stack";

const App = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return <SplashScreen />;
  }

  const Stack = createStackNavigator();

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen
          name="Home"
          component={HomePage}
          options={{ title: "Home Page" }}
        />
        <Stack.Screen
          name="Level"
          component={LevelPage}
          options={{ title: "Level Page" }}
        />
        <Stack.Screen
          name="Results"
          component={ResultsPage} // Ensure this component exists
          options={{ title: "Results Page" }}
        />
        {/* Add more screens here if needed */}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});

export default App;
