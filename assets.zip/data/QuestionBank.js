const questionBank = [
  {
    level: 1,
    questions: [
      {
        question: "What is the capital of France?",
        options: ["Berlin", "Madrid", "Paris", "Lisbon"],
        answer: "Paris",
        image: "https://via.placeholder.com/150?text=Paris", // Replace with actual image URL
      },
      {
        question: "Which planet is known as the Red Planet?",
        options: ["Earth", "Mars", "Jupiter", "Saturn"],
        answer: "Mars",
        image: "https://via.placeholder.com/150?text=Mars", // Replace with actual image URL
      },
      {
        question: "What is the largest ocean on Earth?",
        options: [
          "Atlantic Ocean",
          "Indian Ocean",
          "Arctic Ocean",
          "Pacific Ocean",
        ],
        answer: "Pacific Ocean",
        image: "https://via.placeholder.com/150?text=Pacific+Ocean", // Replace with actual image URL
      },
      {
        question: "Who wrote 'To Kill a Mockingbird'?",
        options: [
          "Harper Lee",
          "J.K. Rowling",
          "Ernest Hemingway",
          "F. Scott Fitzgerald",
        ],
        answer: "Harper Lee",
        image: "https://via.placeholder.com/150?text=Harper+Lee", // Replace with actual image URL
      },
      {
        question: "What is the chemical symbol for gold?",
        options: ["Au", "Ag", "Pb", "Fe"],
        answer: "Au",
        image: "https://via.placeholder.com/150?text=Gold", // Replace with actual image URL
      },
      // Add more questions for level 1
    ],
  },
  {
    level: 2,
    questions: [
      {
        question: "What is the smallest prime number?",
        options: ["1", "2", "3", "5"],
        answer: "2",
        image: "https://via.placeholder.com/150?text=Prime+Number", // Replace with actual image URL
      },
      {
        question: "What gas do plants primarily use for photosynthesis?",
        options: ["Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"],
        answer: "Carbon Dioxide",
        image: "https://via.placeholder.com/150?text=Photosynthesis", // Replace with actual image URL
      },
      {
        question: "Which element has the atomic number 1?",
        options: ["Helium", "Hydrogen", "Lithium", "Boron"],
        answer: "Hydrogen",
        image: "https://via.placeholder.com/150?text=Hydrogen", // Replace with actual image URL
      },
      {
        question: "What is the hardest natural substance on Earth?",
        options: ["Gold", "Iron", "Diamond", "Platinum"],
        answer: "Diamond",
        image: "https://via.placeholder.com/150?text=Diamond", // Replace with actual image URL
      },
      {
        question: "Which country is known as the Land of the Rising Sun?",
        options: ["China", "Japan", "South Korea", "Thailand"],
        answer: "Japan",
        image: "https://via.placeholder.com/150?text=Japan", // Replace with actual image URL
      },
      // Add more questions for level 2
    ],
  },
  // Add more levels and questions as needed
];

export default questionBank;
