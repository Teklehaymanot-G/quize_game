import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import { useNavigation } from "@react-navigation/native";

const HomePage = ({ currentLevel, totalScore }) => {
  const navigation = useNavigation();
  console.log("first--", "level");

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to the Quiz Game!</Text>
      <View style={styles.infoContainer}>
        <Text style={styles.info}>Current Level: {currentLevel}</Text>
        <Text style={styles.info}>Total Score: {totalScore}</Text>
      </View>
      <View style={styles.buttonContainer}>
        <Button
          title="Start Level 1"
          onPress={() => navigation.navigate("Level", { level: 1 })}
        />
        <Button
          title="Start Level 2"
          onPress={() => navigation.navigate("Level", { level: 2 })}
        />
        {/* Add more buttons for additional levels */}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#f5f5f5",
    color: "#000",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  infoContainer: {
    marginBottom: 30,
  },
  info: {
    fontSize: 18,
    marginBottom: 10,
  },
  buttonContainer: {
    width: "100%",
    maxWidth: 300,
  },
});

export default HomePage;
