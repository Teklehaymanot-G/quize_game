import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import React from "react";
import HomePage from "./HomePage"; // Adjust the path as needed
import LevelPage from "./LevelPage"; // Create this component for handling level questions
import ResultsPage from "./ResultPage";

const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen
          name="Home"
          component={HomePage}
          options={{ title: "Home Page" }}
        />
        <Stack.Screen
          name="Level"
          component={LevelPage}
          options={{ title: "Level Page" }}
        />
        <Stack.Screen
          name="Results"
          component={ResultsPage} // Ensure this component exists
          options={{ title: "Results Page" }}
        />
        {/* Add more screens here if needed */}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
