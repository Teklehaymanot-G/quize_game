import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, Alert } from "react-native";
import NavigationButtons from "../components/NavigationButtons";
import Question from "../components/Question";
import StatusIndicator from "../components/StatusIndicator";
import questionBank from "../data/QuestionBank";

const LevelPage = ({ route, navigation }) => {
  const { level } = route.params;
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOptions, setSelectedOptions] = useState({});
  const [elapsedTime, setElapsedTime] = useState(0); // Track elapsed time
  const [timer, setTimer] = useState(300); // Set timer duration (in seconds)
  const questions = questionBank.find((q) => q.level === level).questions;

  useEffect(() => {
    if (timer === 0) {
      Alert.alert("Time is up!", "Redirecting to results page.");
      navigation.navigate("Results", { elapsedTime, selectedOptions }); // Pass elapsed time and selected options to results page
      return;
    }
    const interval = setInterval(() => {
      setTimer((prev) => prev - 1);
      setElapsedTime((prev) => prev + 1); // Track elapsed time
    }, 1000);
    return () => clearInterval(interval);
  }, [timer, navigation]);

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else {
      Alert.alert("No more questions!", "You are on the last question.");
    }
  };

  const handlePrev = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex((prev) => prev - 1);
    } else {
      Alert.alert("No previous questions!", "You are on the first question.");
    }
  };

  const handleAnswerSelection = (selectedRadioButton) => {
    setSelectedOptions({
      ...selectedOptions,
      [currentQuestionIndex]: selectedRadioButton.value,
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.questionHeader}>
        Question {currentQuestionIndex + 1}:
      </Text>
      <Question
        currentQuestionIndex={currentQuestionIndex}
        question={questions[currentQuestionIndex]}
        selectedOption={selectedOptions[currentQuestionIndex]}
        onSelectOption={handleAnswerSelection}
      />
      <NavigationButtons
        onNext={handleNext}
        onPrev={handlePrev}
        isNextDisabled={currentQuestionIndex === questions.length - 1}
        isPrevDisabled={currentQuestionIndex === 0}
      />
      <StatusIndicator
        questions={questions}
        selectedOptions={selectedOptions}
      />
      <Text style={styles.timer}>Time Left: {timer}s</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#fff",
  },
  questionHeader: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10,
  },
  timer: {
    fontSize: 18,
    marginTop: 20,
    textAlign: "center",
  },
});

export default LevelPage;
