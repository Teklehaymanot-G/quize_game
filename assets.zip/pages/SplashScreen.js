import React from "react";
import { View, Image, StyleSheet, Dimensions } from "react-native";

const { width, height } = Dimensions.get("window");

const SplashScreen = () => {
  return (
    <View style={styles.container}>
      <Image
        source={require("../assets/splash.jpg")} // Replace with your image path
        style={styles.image}
        resizeMode="contain"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#ffffff", // Optional: set a background color
  },
  image: {
    width: width * 0.8, // Adjust size as needed
    height: height * 0.4, // Adjust size as needed
  },
});

export default SplashScreen;
