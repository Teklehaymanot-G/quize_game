import React, { useState, useEffect } from "react";
import { View, Text, Button, StyleSheet, Image, Alert } from "react-native";
import questionBank from "../data/QuestionBank";

const LevelPage = ({ route, navigation }) => {
  const { level } = route.params;
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [elapsedTime, setElapsedTime] = useState(0); // Track elapsed time
  const [timer, setTimer] = useState(30); // Set timer duration (in seconds)
  const questions = questionBank.find((q) => q.level === level).questions;

  useEffect(() => {
    if (timer === 0) {
      Alert.alert("Time is up!", "Redirecting to results page.");
      navigation.navigate("Results", { elapsedTime }); // Pass elapsed time to results page
      return;
    }
    const interval = setInterval(() => {
      setTimer((prev) => prev - 1);
      setElapsedTime((prev) => prev + 1); // Track elapsed time
    }, 1000);
    return () => clearInterval(interval);
  }, [timer, navigation]);

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else {
      Alert.alert("Level Completed!", "Redirecting to results page.");
      navigation.navigate("Results", { elapsedTime }); // Pass elapsed time to results page
    }
  };

  const handleAnswerSelection = (selectedOption) => {
    // Here you can handle the logic of checking if the answer is correct
    // For now, we'll just move to the next question
    handleNext();
  };

  const question = questions[currentQuestionIndex];

  return (
    <View style={styles.container}>
      <Text style={styles.question}>{question.question}</Text>
      {question.image && (
        <Image source={{ uri: question.image }} style={styles.image} />
      )}
      {question.options.map((option, index) => (
        <Button
          key={index}
          title={option}
          onPress={() => handleAnswerSelection(option)} // Redirect to the next question on selection
        />
      ))}
      <Text style={styles.timer}>Time Left: {timer}s</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#fff",
  },
  question: {
    fontSize: 18,
    marginBottom: 20,
  },
  image: {
    width: "100%",
    height: 200,
    marginBottom: 20,
  },
  timer: {
    fontSize: 18,
    marginTop: 20,
    textAlign: "center",
  },
});

export default LevelPage;
