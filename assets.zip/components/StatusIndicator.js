// StatusIndicator.js
import React from "react";
import { View, Text, StyleSheet } from "react-native";

const StatusIndicator = ({ questions, selectedOptions }) => {
  return (
    <View style={styles.statusContainer}>
      <Text style={styles.statusTitle}>Level Status:</Text>
      {questions.map((_, index) => (
        <View key={index} style={styles.statusIndicator}>
          <Text style={styles.statusIndicatorText}>
            {index + 1}: {selectedOptions[index] ? "Answered" : "Not Answered"}
          </Text>
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  statusContainer: {
    marginTop: 20,
  },
  statusTitle: {
    fontSize: 18,
    marginBottom: 10,
  },
  statusIndicator: {
    flexDirection: "row",
    marginBottom: 5,
  },
  statusIndicatorText: {
    fontSize: 16,
  },
});

export default StatusIndicator;
