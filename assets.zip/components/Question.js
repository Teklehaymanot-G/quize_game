// Question.js
import React from "react";
import { View, Text, StyleSheet, Image } from "react-native";
import RadioGroup from "react-native-radio-buttons-group";

const Question = ({
  currentQuestionIndex,
  question,
  selectedOption,
  onSelectOption,
}) => {
  const radioButtonsData = question.options.map((option, index) => ({
    id: `${index}`,
    label: option,
    value: option,
    selected: selectedOption === option,
  }));

  return (
    <View>
      <Text style={styles.questionText}>
        Question {currentQuestionIndex + 1}
      </Text>
      <Text style={styles.questionText}>{question.question}</Text>
      {question.image && (
        <Image source={{ uri: question.image }} style={styles.image} />
      )}
      <RadioGroup
        radioButtons={radioButtonsData}
        onPress={onSelectOption}
        containerStyle={styles.radioGroup}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  questionNumber: {
    fontSize: 18,
    marginBottom: 20,
    backgroundColor: "#FF0000",
    color: "#FFFFFF",
  },
  questionText: {
    fontSize: 18,
    marginBottom: 20,
  },
  image: {
    width: "100%",
    height: 200,
    marginBottom: 20,
  },
  radioGroup: {
    alignItems: "flex-start",
    marginTop: 10,
  },
});

export default Question;
